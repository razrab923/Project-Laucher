package com.projectos.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Project OS Launcher prototype. Built-in widgets are launcher cards, not Android AppWidgets. */
public class MainActivity extends Activity {
    private static final String PREFS = "project_os_preferences";
    private static final String KEY_THEME = "theme"; // light, dark, system
    private static final String KEY_GLASS = "liquid_glass";
    private static final String KEY_ACCENT = "accent";
    private static final String KEY_NOTE = "quick_note";

    private final List<AppEntry> apps = new ArrayList<>();
    private final Handler clockHandler = new Handler();
    private SharedPreferences prefs;
    private LinearLayout root;
    private LinearLayout appGrid;
    private EditText search;
    private TextView clockText;
    private TextView dateText;
    private boolean dark;
    private boolean glass;
    private int accent;
    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (clockText != null) clockText.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            if (dateText != null) dateText.setText(new SimpleDateFormat("EEEE, d MMMM", new Locale("ru")).format(new Date()));
            clockHandler.postDelayed(this, 30_000);
        }
    };

    private static class AppEntry {
        String label;
        String packageName;
        android.graphics.drawable.Drawable icon;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        applyPreferences();
        loadApps();
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        clockHandler.removeCallbacks(clockTick);
        clockHandler.post(clockTick);
        loadApps();
        if (root != null) buildUi();
    }

    @Override protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(clockTick);
    }

    private void applyPreferences() {
        String theme = prefs.getString(KEY_THEME, "light");
        if ("system".equals(theme)) {
            int night = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            dark = night == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        } else dark = "dark".equals(theme);
        glass = prefs.getBoolean(KEY_GLASS, true);
        accent = prefs.getInt(KEY_ACCENT, Color.rgb(92, 105, 238));
    }

    private void loadApps() {
        apps.clear();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> found = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL);
        for (ResolveInfo ri : found) {
            if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
            AppEntry e = new AppEntry();
            e.label = ri.loadLabel(pm).toString();
            e.packageName = ri.activityInfo.packageName;
            e.icon = ri.loadIcon(pm);
            apps.add(e);
        }
        Collections.sort(apps, Comparator.comparing(a -> a.label.toLowerCase(new Locale("ru"))));
    }

    private int bg() { return dark ? Color.rgb(13, 16, 26) : Color.rgb(239, 242, 250); }
    private int textColor() { return dark ? Color.WHITE : Color.rgb(28, 32, 45); }
    private int secondary() { return dark ? Color.rgb(190, 196, 211) : Color.rgb(105, 112, 132); }
    private int panelColor() { return dark ? (glass ? Color.argb(178, 46, 53, 72) : Color.rgb(37, 42, 57)) : (glass ? Color.argb(190, 255, 255, 255) : Color.rgb(255, 255, 255)); }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable panel(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (glass) d.setStroke(dp(1), dark ? Color.argb(85, 255, 255, 255) : Color.argb(180, 255, 255, 255));
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void buildUi() {
        clockHandler.removeCallbacks(clockTick);
        applyPreferences();
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(bg());
        window.getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));
        root.setBackgroundColor(bg());
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("project os", 19, textColor(), true);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView menu = text("☰", 23, textColor(), false);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Настройки Project OS");
        menu.setPadding(dp(12), dp(4), dp(4), dp(4));
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollLp.topMargin = dp(8);
        root.addView(scroll, scrollLp);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);

        dateText = text("", 14, secondary(), false);
        LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-1, -2);
        dateLp.topMargin = dp(14);
        content.addView(dateText, dateLp);
        clockText = text("", 48, textColor(), false);
        clockText.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        content.addView(clockText);

        buildWidgets(content);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(textColor());
        search.setHintTextColor(secondary());
        search.setHint("⌕   Поиск приложений");
        search.setPadding(dp(16), 0, dp(16), 0);
        search.setBackground(panel(panelColor(), 20));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(50));
        searchLp.topMargin = dp(18);
        content.addView(search, searchLp);

        TextView section = text("Приложения", 18, textColor(), true);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.topMargin = dp(20);
        content.addView(section, sectionLp);

        appGrid = new LinearLayout(this);
        appGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(-1, -2);
        gridLp.topMargin = dp(10);
        content.addView(appGrid, gridLp);
        renderApps("");
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderApps(s.toString()); }
            @Override public void afterTextChanged(android.text.Editable e) { }
        });

        buildDock();
        clockTick.run();
    }

    private void buildWidgets(LinearLayout content) {
        TextView widgetHeading = text("Виджеты", 16, textColor(), true);
        LinearLayout.LayoutParams headingLp = new LinearLayout.LayoutParams(-1, -2);
        headingLp.topMargin = dp(16);
        content.addView(widgetHeading, headingLp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(10);
        content.addView(row, rowLp);
        row.addView(widgetCard("▦", "Календарь", new SimpleDateFormat("d MMMM", new Locale("ru")).format(new Date()), () -> openCalendar()), new LinearLayout.LayoutParams(0, dp(112), 1));
        View gap = new View(this);
        row.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        row.addView(widgetCard("◉", "Аккумулятор", batteryText(), () -> openBattery()), new LinearLayout.LayoutParams(0, dp(112), 1));

        LinearLayout note = new LinearLayout(this);
        note.setOrientation(LinearLayout.VERTICAL);
        note.setPadding(dp(16), dp(13), dp(16), dp(13));
        note.setBackground(panel(panelColor(), 22));
        TextView noteTitle = text("✎  Быстрая заметка", 14, textColor(), true);
        TextView noteBody = text(prefs.getString(KEY_NOTE, "Нажми, чтобы записать идею…"), 13, secondary(), false);
        noteBody.setMaxLines(2);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(-1, -2);
        bodyLp.topMargin = dp(7);
        note.addView(noteTitle);
        note.addView(noteBody, bodyLp);
        note.setOnClickListener(v -> editNote());
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(10);
        content.addView(note, noteLp);
    }

    private View widgetCard(String symbol, String title, String value, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(15), dp(12), dp(12), dp(12));
        card.setBackground(panel(panelColor(), 22));
        TextView glyph = text(symbol, 22, accent, true);
        TextView heading = text(title, 13, secondary(), true);
        TextView body = text(value, 17, textColor(), true);
        LinearLayout.LayoutParams h = new LinearLayout.LayoutParams(-1, -2);
        h.topMargin = dp(4);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(-1, -2);
        b.topMargin = dp(3);
        card.addView(glyph);
        card.addView(heading, h);
        card.addView(body, b);
        card.setOnClickListener(v -> action.run());
        return card;
    }

    private String batteryText() {
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return "Состояние";
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return level >= 0 && scale > 0 ? Math.round(level * 100f / scale) + "%" : "—";
    }

    private void openCalendar() {
        try { startActivity(new Intent(Intent.ACTION_INSERT, android.provider.CalendarContract.Events.CONTENT_URI)); }
        catch (Exception e) { showMessage("Календарь", "На устройстве не найдено приложение календаря."); }
    }

    private void openBattery() {
        try { startActivity(new Intent(Intent.ACTION_POWER_USAGE_SUMMARY)); }
        catch (Exception e) { showMessage("Аккумулятор", batteryText()); }
    }

    private void editNote() {
        EditText input = new EditText(this);
        input.setText(prefs.getString(KEY_NOTE, ""));
        input.setHint("Твоя заметка");
        input.setMinLines(2);
        input.setGravity(Gravity.TOP);
        new AlertDialog.Builder(this).setTitle("Быстрая заметка").setView(input)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, w) -> {
                    prefs.edit().putString(KEY_NOTE, input.getText().toString().trim()).apply();
                    buildUi();
                }).show();
    }

    private void renderApps(String filter) {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        List<AppEntry> visible = new ArrayList<>();
        String query = filter.toLowerCase(new Locale("ru"));
        for (AppEntry app : apps) if (app.label.toLowerCase(new Locale("ru")).contains(query)) visible.add(app);
        int columns = 4;
        for (int start = 0; start < visible.size(); start += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            for (int i = start; i < Math.min(start + columns, visible.size()); i++) {
                row.addView(appCell(visible.get(i)), new LinearLayout.LayoutParams(0, dp(104), 1));
            }
            for (int i = Math.min(columns, visible.size() - start); i < columns; i++) row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(104), 1));
            appGrid.addView(row);
        }
        if (visible.isEmpty()) {
            TextView empty = text("Приложения не найдены", 14, secondary(), false);
            empty.setGravity(Gravity.CENTER);
            appGrid.addView(empty);
        }
    }

    private View appCell(AppEntry app) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        cell.setPadding(dp(2), dp(5), dp(2), dp(5));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(app.icon);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        cell.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));
        TextView label = text(app.label, 11, textColor(), false);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(5);
        cell.addView(label, labelLp);
        cell.setOnClickListener(v -> launch(app));
        cell.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this).setTitle(app.label)
                    .setItems(new String[]{"Открыть приложение", "Информация о приложении"}, (d, which) -> {
                        if (which == 0) launch(app);
                        else {
                            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            i.setData(android.net.Uri.parse("package:" + app.packageName));
                            startActivity(i);
                        }
                    }).show();
            return true;
        });
        return cell;
    }

    private void launch(AppEntry app) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(app.packageName);
            if (i != null) startActivity(i);
        } catch (ActivityNotFoundException ignored) { }
    }

    private void buildDock() {
        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(10), dp(7), dp(10), dp(7));
        dock.setBackground(panel(panelColor(), 25));
        int count = Math.min(4, apps.size());
        for (int i = 0; i < count; i++) {
            AppEntry app = apps.get(i);
            FrameLayout item = new FrameLayout(this);
            ImageView image = new ImageView(this);
            image.setImageDrawable(app.icon);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            item.addView(image, new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER));
            item.setContentDescription(app.label);
            item.setOnClickListener(v -> launch(app));
            dock.addView(item, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(66));
        lp.topMargin = dp(9);
        root.addView(dock, lp);
    }

    private void showMenu() {
        String theme = prefs.getString(KEY_THEME, "light");
        String themeLabel = "dark".equals(theme) ? "Тёмная" : "system".equals(theme) ? "Как в системе" : "Светлая";
        String[] options = {"Настройки темы (" + themeLabel + ")", "Жидкое стекло: " + (glass ? "включено" : "выключено"), "Акцентный цвет", "Обои устройства", "Обновить приложения", "О Project OS"};
        new AlertDialog.Builder(this).setTitle("Project OS").setItems(options, (d, which) -> {
            if (which == 0) chooseTheme();
            else if (which == 1) { prefs.edit().putBoolean(KEY_GLASS, !glass).apply(); buildUi(); }
            else if (which == 2) chooseAccent();
            else if (which == 3) {
                try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), "Выбрать обои")); }
                catch (Exception ignored) { }
            } else if (which == 4) { loadApps(); buildUi(); }
            else if (which == 5) showMessage("Project OS Launcher 0.2", "Домашний экран, системные иконки приложений, встроенные виджеты, темы, акцентный цвет и эффект «Жидкое стекло».\n\nЭто прототип лаунчера Android, а не самостоятельная операционная система.");
        }).show();
    }

    private void chooseTheme() {
        String[] names = {"Светлая", "Тёмная", "Как в системе"};
        String[] values = {"light", "dark", "system"};
        String current = prefs.getString(KEY_THEME, "light");
        int checked = "dark".equals(current) ? 1 : "system".equals(current) ? 2 : 0;
        new AlertDialog.Builder(this).setTitle("Оформление").setSingleChoiceItems(names, checked, (dialog, which) -> {
            prefs.edit().putString(KEY_THEME, values[which]).apply();
            dialog.dismiss();
            buildUi();
        }).setNegativeButton("Отмена", null).show();
    }

    private void chooseAccent() {
        String[] names = {"Синий", "Фиолетовый", "Бирюзовый", "Розовый", "Оранжевый"};
        int[] colors = {Color.rgb(92, 105, 238), Color.rgb(143, 92, 224), Color.rgb(0, 155, 151), Color.rgb(226, 91, 151), Color.rgb(235, 137, 54)};
        new AlertDialog.Builder(this).setTitle("Акцентный цвет").setItems(names, (dialog, which) -> {
            prefs.edit().putInt(KEY_ACCENT, colors[which]).apply();
            buildUi();
        }).show();
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Понятно", null).show();
    }
}
