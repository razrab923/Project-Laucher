@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "BASE_DIR=%~dp0"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME_DIR=%GRADLE_USER_HOME%\wrapper\manual\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME_DIR%\bin\gradle.bat" goto run
if not exist "%GRADLE_HOME_DIR%" mkdir "%GRADLE_HOME_DIR%\.."
set "ARCHIVE=%GRADLE_USER_HOME%\wrapper\manual\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%ARCHIVE%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ARCHIVE%'"
  if errorlevel 1 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ARCHIVE%' '%GRADLE_USER_HOME%\wrapper\manual'"
if errorlevel 1 exit /b 1
:run
call "%GRADLE_HOME_DIR%\bin\gradle.bat" -p "%BASE_DIR%" %*
exit /b %ERRORLEVEL%
